import Script from "next/script";
export default function Home(){return <><div id="shop"><p>Đang mở WorkHard…</p></div><Script src="/shop-edeacb931e3c.js" strategy="afterInteractive"/></>}
